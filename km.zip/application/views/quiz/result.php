<div class="page-content-wrapper py-3">
    <div class="container">
        <div class="card image-gallery-card direction-rtl">
            <div class="card-body">
                <img class="mb-3 rounded" src="<?=base_url()?>/assets/img/bg-img/13.jpg" alt="">
                <h5>Selamat</h5>
                <p>Kamu telah berhasil mengerjakan</p>
                <a href="<?= base_url("quiz/rekomendasi")?>" class="btn btn-primary mt-3 w-100">Kirim</a>
            </div>
        </div>
    </div>
</div>