<div class="page-content-wrapper py-3">
    <div class="container">
        <div class="card image-gallery-card direction-rtl">
            <div class="card-body">
                <img class="mb-3 rounded" src="<?= base_url() ?>/assets/img/bg-img/13.jpg" alt="">
                <h3>UJIAN</h3>
                <p>Untuk menganalisis kebutuhan belajar yang sesuai dengan kemampuanmu, selesaikan soal berikut untuk memudahkan sistem menentukan materi belajar yang cocok buat kamu.</p>
                <h6>Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus dolorem totam nulla tempore dicta ipsam doloremque sed nesciunt consequuntur maxime?</h6>
                <p align="left">
                    <input type="hidden" name="id[]" value="1">
                    <input type="radio" name="soal[1]" value="A" required> A. <br>
                    <input type="radio" name="soal[1]" value="B"> B. <br>
                    <input type="radio" name="soal[1]" value="C"> C. <br>
                    <input type="radio" name="soal[1]" value="D"> D. <br>
                    <input type="radio" name="soal[1]" value="E"> E. <br>
                </p>
                <hr>
                <h6>Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus dolorem totam nulla tempore dicta ipsam doloremque sed nesciunt consequuntur maxime?</h6>
                <p align="left">
                    <input type="hidden" name="id[]" value="1">
                    <input type="radio" name="soal[1]" value="A" required> A. <br>
                    <input type="radio" name="soal[1]" value="B"> B. <br>
                    <input type="radio" name="soal[1]" value="C"> C. <br>
                    <input type="radio" name="soal[1]" value="D"> D. <br>
                    <input type="radio" name="soal[1]" value="E"> E. <br>
                </p>
                <hr>
                <h6>Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus dolorem totam nulla tempore dicta ipsam doloremque sed nesciunt consequuntur maxime?</h6>
                <p align="left">
                    <input type="hidden" name="id[]" value="1">
                    <input type="radio" name="soal[1]" value="A" required> A. <br>
                    <input type="radio" name="soal[1]" value="B"> B. <br>
                    <input type="radio" name="soal[1]" value="C"> C. <br>
                    <input type="radio" name="soal[1]" value="D"> D. <br>
                    <input type="radio" name="soal[1]" value="E"> E. <br>
                </p>
                <hr>
                <h6>Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus dolorem totam nulla tempore dicta ipsam doloremque sed nesciunt consequuntur maxime?</h6>
                <p align="left">
                    <input type="hidden" name="id[]" value="1">
                    <input type="radio" name="soal[1]" value="A" required> A. <br>
                    <input type="radio" name="soal[1]" value="B"> B. <br>
                    <input type="radio" name="soal[1]" value="C"> C. <br>
                    <input type="radio" name="soal[1]" value="D"> D. <br>
                    <input type="radio" name="soal[1]" value="E"> E. <br>
                </p>
                <hr>
                <h6>Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus dolorem totam nulla tempore dicta ipsam doloremque sed nesciunt consequuntur maxime?</h6>
                <p align="left">
                    <input type="hidden" name="id[]" value="1">
                    <input type="radio" name="soal[1]" value="A" required> A. <br>
                    <input type="radio" name="soal[1]" value="B"> B. <br>
                    <input type="radio" name="soal[1]" value="C"> C. <br>
                    <input type="radio" name="soal[1]" value="D"> D. <br>
                    <input type="radio" name="soal[1]" value="E"> E. <br>
                </p>
                <div class="form-check mb-3">
                    <input class="form-check-input" id="checkedCheckbox" type="checkbox" value="" required>
                    <label class="form-check-label text-muted fw-normal" for="checkedCheckbox">Saya yakin sudah menyelesaikan tes</label>
                </div>
                <a href="<?=base_url("quiz/result")?>" class="btn btn-primary w-100 d-flex align-items-center justify-content-center" type="button">
                    Selanjutnya <i class="bi bi-arrow-right fz-16 ms-1"></i>
                </a>
            </div>
        </div>
    </div>
</div>