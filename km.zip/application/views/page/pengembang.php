<div class="page-content-wrapper py-3">
    <div class="container">
        <div class="card image-gallery-card direction-rtl">
            <div class="card-body">
                <img class="mb-3 rounded" src="<?=base_url()?>/assets/img/template/fitrah.jpg" alt="">
                <h5>Fitrah Izul Falaq</h5>
                <p>Putra pedagang loak elektronik. Sejak kecil, mahir mengotak-atik loakan milik bapaknya menjadi mainan untuk jual ke temannya. Semasa SMK, pernah mendapat 12 prestasi sehingga mendapat hadiah sebagai Siswa Berprestasi Jurusan TKJ.
                </p>
                <p>Dilanjutkan semasa kuliah, mengulang hal yang sama hingga akhirnya diamanahi sebagai Mahasiswa Berprestasi 3 UM 2018. Sebelum lulus tahun 2020, diterima sebagai tenaga Ahli IT UPT Pelatihan Koperasi dan UKM Provinsi Jawa Timur hingga sekarang.</p>
                <a href="https://fitrah.sch.id" class="btn btn-primary mt-3 w-100">Contact Us</a>
            </div>
        </div>
    </div>
</div>