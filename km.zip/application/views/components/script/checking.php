<!-- Internet Connection Status -->
<div class="internet-connection-status" id="internetStatus"></div>

